var names = document.getElementById('inputName')

console.log(names)

function myAlert() {
    alert("You have entered these details:" + names);
}

